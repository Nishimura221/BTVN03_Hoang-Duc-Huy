package model;

public class Student {
    private String name;
    private int date_of_birth;
    private int age;
    private int weight;
    private double height;
    private String lop;
    private String ID;

    public Student(String name, int date_of_birth, int age, int weight, double height, String lop, String ID) {
        this.name = name;
        this.date_of_birth = date_of_birth;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.lop = lop;
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(int date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    public String printValue(int age){
        return"Tuoi la "+age;
    }
    public String printValue(int age, String name){
        return name+": "+age;
    }
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", date_of_birth=" + date_of_birth +
                ", age=" + age +
                ", weight=" + weight +
                ", height=" + height +
                ", lop='" + lop + '\'' +
                ", ID='" + ID + '\'' +
                '}';
    }
}

