package main;
import model.Student;
import model.Teacher;

import static main.ChucNang.calculateBMIOfStudent;
import static main.ChucNang.praseStringToInt;

public class Test {
    public static void main(String[] args){
        Student FPT= new Student("Hoang Huy",7,19,65,1.75,"Software Engineering","SE192320");
        System.out.println(FPT.toString());//Test getter
        FPT.setHeight(1.65);//Set height
        FPT.setAge(20);//Set age
        FPT.setName("Nishimura Itsuki");//Set name
        System.out.println(FPT.toString()+"  (da sua du lieu)");//Test setter of student java
        Teacher SE= new Teacher("SE162340","Tuan","Software Engineering",31);
        System.out.println(SE.toString());//Test getter teacher java
        SE.setAge(25);//Set age
        SE.setNameTeacher("Thong");//Set name
        System.out.println(SE.toString()+"  (da sua du lieu)");//Test Setter of teacher java
        double BMI_number=calculateBMIOfStudent(FPT.getHeight(), FPT.getWeight());//Test Chuc Nang java
        System.out.println("Chi so BMI cua "+FPT.getName()+" la "+BMI_number);//Test Chuc Nang java
        String a="234";//Test Chuc Nang java
        int ConvertFromStringToInteger=praseStringToInt(a);//Test Chuc Nang java
        System.out.println("String= "+a+" to Integer "+ConvertFromStringToInteger);//Test Chuc Nang java
        System.out.println(FPT.printValue(FPT.getAge()));//Test method Overload
        System.out.println(FPT.printValue(FPT.getAge(),"Huy"));//Test method Overload
    }


}
