package main;

public class ChucNang {
       public static int praseStringToInt(String str){
           int a= Integer.parseInt(str);
           return a;
       }
       public static double calculateBMIOfStudent(double height, int weight){
           double BMI;
           String rtx= Integer.toString(weight);
           double kg = Double.parseDouble(rtx);
           BMI = kg/(height*height);
           return BMI;
       }
}
